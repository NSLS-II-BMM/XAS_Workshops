######################################################### -*- python -*-
# Cut and paste this line to import your macro after editing:
#
#     %run -i '/nsls2/data/bmm/XAS/2023-3/312411/2023-10-12//Fe_macro.py'
#
# Verify that your macro was loaded correctly:
#
#     Fe_macro??
#
# Then run the macro:
#
#     RE(Fe_macro())
#                /
############### / #######################################
#              / 
#             /  Note that you are defining a command
#            /   that gets run in BlueSky
#           V
from BMM.suspenders import BMM_suspenders, BMM_clear_suspenders
def Fe_macro(dryrun=False, ref=False):
    '''User-defined macro for running a sequence of XAFS measurements
    using a standard sample wheel
    '''
    (ok, text) = BMM_clear_to_start()
    if ok is False:
        print(error_msg('\n'+text) + bold_msg('Quitting macro....\n'))
        return(yield from null())

    BMMuser.macro_dryrun = dryrun
    BMMuser.prompt, BMMuser.running_macro = False, True
    BMMuser.instrument = 'double wheel'
    BMM_log_info('Beginning Fe_macro')
    def main_plan(ref):

        ### ---------------------------------------------------------------------------------------
        ### BOILERPLATE ABOVE THIS LINE -----------------------------------------------------------
        ##  EDIT BELOW THIS LINE
        #<--indentation matters!

        report("Wheel sequence 1 of 4", level="bold", slack=True)
        yield from slot(1)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_det, 205.00)
        yield from xafs('Fe.ini', filename='Fe_Wustite', sample='FeO', prep='powder on tape')
        close_last_plot()

        report("Wheel sequence 2 of 4", level="bold", slack=True)
        yield from slot(2)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_det, 205.00)
        yield from xafs('Fe.ini', filename='Fe_Hematite', sample='alpha-Fe2O3', prep='powder on tape')
        close_last_plot()

        report("Wheel sequence 3 of 4", level="bold", slack=True)
        yield from slot(22)
        yield from xafs_wheel.inner() # inner ring
        yield from xafs('Fe.ini', filename='Fe_Pyrite', sample='FeS2', prep='powder on tape', comment='probably a bit oxidized')
        close_last_plot()

        report("Wheel sequence 4 of 4", level="bold", slack=True)
        yield from slot(24)
        yield from xafs_wheel.inner() # inner ring
        yield from mv(xafs_det, 60.00)
        yield from xafs('Fe.ini', filename='Fe_Vesuvianite', mode='both', sample='Ca10(Mg,Fe)Al4(Si2O7)2(SiO4)4(OH)4', prep='PEG pellet', comment='courtesy Martin Stennett, University of Sheffield', times='1 1 1 1')
        close_last_plot()

        if not dryrun:
            BMMuser.running_macro = False
            BMM_clear_suspenders()
            yield from shb.close_plan()


        ##  EDIT ABOVE THIS LINE
        ### BOILERPLATE BELOW THIS LINE -----------------------------------------------------------
        ### ---------------------------------------------------------------------------------------

    def cleanup_plan():
        yield from end_of_macro()
        yield from xafs_wheel.reset()
        elapsed_time(start)
        print(bold_msg('[Hint] to start Athena:\t\t') + '%athena')


    start = time.time()
    
    BMM_suspenders()
    yield from finalize_wrapper(main_plan(ref), cleanup_plan())    
    yield from end_of_macro()
    BMM_log_info('Fe_macro finished!')
