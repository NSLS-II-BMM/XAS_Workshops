######################################################### -*- python -*-
# Cut and paste this line to import your macro after editing:
#
#     %run -i '/nsls2/data/bmm/XAS/2023-3/312411/2023-10-12//FeS2_macro.py'
#
# Verify that your macro was loaded correctly:
#
#     FeS2_macro??
#
# Then run the macro:
#
#     RE(FeS2_macro())
#                /
############### / #######################################
#              / 
#             /  Note that you are defining a command
#            /   that gets run in BlueSky
#           V
from BMM.suspenders import BMM_suspenders, BMM_clear_suspenders
def FeS2_macro(dryrun=False, ref=False):
    '''User-defined macro for running a sequence of XAFS measurements
    using a standard sample wheel
    '''
    (ok, text) = BMM_clear_to_start()
    if ok is False:
        print(error_msg('\n'+text) + bold_msg('Quitting macro....\n'))
        return(yield from null())

    BMMuser.macro_dryrun = dryrun
    BMMuser.prompt, BMMuser.running_macro = False, True
    BMMuser.instrument = 'double wheel'
    BMM_log_info('Beginning FeS2_macro')
    def main_plan(ref):

        ### ---------------------------------------------------------------------------------------
        ### BOILERPLATE ABOVE THIS LINE -----------------------------------------------------------
        ##  EDIT BELOW THIS LINE
        #<--indentation matters!

        for rep in range(2):

            report(f"Wheel sequence {1+5*rep} of 10", level="bold", slack=True)
            yield from slot(4)
            yield from xafs_wheel.inner() # inner ring
            yield from mv(xafs_det, 90.00)
            yield from change_edge('Fe', edge='K', focus=False)
            yield from xafs('FeS2.ini', filename='Fe_Fe-FeS2-pristine', nscans=1, sample='FeS2 CNT Li5PS5Cl NMC 3 mg', prep='pristine')
            close_last_plot()

            report(f"Wheel sequence {2+5*rep} of 10", level="bold", slack=True)
            yield from slot(10)
            yield from xafs_wheel.inner() # inner ring
            yield from mv(xafs_det, 70.00)
            yield from xafs('FeS2.ini', filename='Fe_Fe-FeS2-after 1 cycle', nscans=1, sample='FeS2 CNT Li5PS5Cl NMC 3 mg', prep='After 1 cycle')
            close_last_plot()

            report(f"Wheel sequence {3+5*rep} of 10", level="bold", slack=True)
            yield from slot(16)
            yield from xafs_wheel.inner() # inner ring
            yield from mv(xafs_det, 90.00)
            yield from xafs('FeS2.ini', filename='Fe_Fe-FeS2-charged_1_7V', nscans=1, sample='FeS2 CNT Li5PS5Cl NMC 3 mg', prep='charged')
            close_last_plot()

            report(f"Wheel sequence {4+5*rep} of 10", level="bold", slack=True)
            yield from slot(18)
            yield from xafs_wheel.inner() # inner ring
            yield from mv(xafs_det, 40.00)
            yield from xafs('FeS2.ini', filename='Fe_Fe-FeS2- after firstdischarge', nscans=1, sample='FeS2 CNT Li5PS5Cl NMC 3 mg', prep='after first discharge')
            close_last_plot()

            report(f"Wheel sequence {5+5*rep} of 10", level="bold", slack=True)
            yield from slot(21)
            yield from xafs_wheel.inner() # inner ring
            yield from mv(xafs_det, 90.00)
            yield from xafs('FeS2.ini', filename='Fe_Fe-FeS2- discharged 2_6V', nscans=1, sample='FeS2 CNT Li5PS5Cl NMC 3 mg', prep='Discharged 2_6')
            close_last_plot()

        if not dryrun:
            BMMuser.running_macro = False
            BMM_clear_suspenders()
            yield from shb.close_plan()


        ##  EDIT ABOVE THIS LINE
        ### BOILERPLATE BELOW THIS LINE -----------------------------------------------------------
        ### ---------------------------------------------------------------------------------------

    def cleanup_plan():
        yield from end_of_macro()
        yield from xafs_wheel.reset()
        elapsed_time(start)
        print(bold_msg('[Hint] to start Athena:\t\t') + '%athena')


    start = time.time()
    
    BMM_suspenders()
    yield from finalize_wrapper(main_plan(ref), cleanup_plan())    
    yield from end_of_macro()
    BMM_log_info('FeS2_macro finished!')
