######################################################### -*- python -*-
# Cut and paste this line to import your macro after editing:
#
#     %run -i '/home/xf06bm/Workspace/Visitors/Lu Ma/2025-03-13/Mn_macro.py'
#
# Verify that your macro was loaded correctly:
#
#     Mn_macro??
#
# Then run the macro:
#
#     RE(Mn_macro())
#                /
############### / #######################################
#              / 
#             /  Note that you are defining a command
#            /   that gets run in BlueSky
#           V
from BMM.suspenders import BMM_suspenders, BMM_clear_suspenders
from BMM.functions import not_at_edge
def Mn_macro(dryrun=False, ref=False):
    '''User-defined macro for running a sequence of XAFS measurements
    using a standard sample wheel
    '''
    (ok, text) = BMM_clear_to_start()
    if ok is False:
        print(error_msg('\n'+text) + bold_msg('Quitting macro....\n'))
        return(yield from null())

    BMMuser.macro_dryrun = dryrun
    BMMuser.prompt, BMMuser.running_macro = False, True
    BMMuser.instrument = 'double wheel'
    BMM_log_info('Beginning Mn_macro')
    def main_plan(ref):

        ### ---------------------------------------------------------------------------------------
        ### BOILERPLATE ABOVE THIS LINE -----------------------------------------------------------
        ##  EDIT BELOW THIS LINE
        #<--indentation matters!

        ## change edge before starting, if needed...
        if not_at_edge('Mn', 'K'):
            yield from change_edge('Mn', edge='K', focus=False)

        report("Wheel sequence 1 of 5", level="bold", slack=True)
        yield from slot(2)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_detx, 205.00)
        yield from xafs('Mn.ini', filename='Mn_Manganosite', sample='MnO', prep='powder on tape', copy=False)
        close_plots()

        report("Wheel sequence 2 of 5", level="bold", slack=True)
        yield from slot(3)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_detx, 205.00)
        yield from xafs('Mn.ini', filename='Mn_Bixbyite', sample='Mn2O3', copy=False)
        close_plots()

        report("Wheel sequence 3 of 5", level="bold", slack=True)
        yield from slot(4)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_detx, 205.00)
        yield from xafs('Mn.ini', filename='Mn_Pyrolucite', sample='MnO2', prep='powder on tape', copy=False)
        close_plots()

        report("Wheel sequence 4 of 5", level="bold", slack=True)
        yield from slot(9)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_detx, 18.00)
        yield from xafs('Mn.ini', filename='Mn_Babingtonite', mode='fluorescence', sample='Ca2Fe0.75Mn0.25FeSi5O14(OH)', prep='PEG pellet', comment='Babingtonite, CM14452; Lane\'s Quarry, Westfield, Hampden County, Massachusetts', bounds='-200 -30 -10 25 560', times='2 2 2 2', copy=False)
        close_plots()

        report("Wheel sequence 5 of 5", level="bold", slack=True)
        yield from xafs_wheel.outer() # outer ring
        yield from mv(xafs_detx, 105.00)
        yield from change_edge('Fe', edge='K', focus=False)
        yield from xafs('Mn.ini', filename='Fe_Babingtonite', mode='fluorescence', element='Fe', sample='Ca2Fe0.75Mn0.25FeSi5O14(OH)', prep='PEG pellet', comment='Babingtonite, CM14452; Lane\'s Quarry, Westfield, Hampden County, Massachusetts', bounds='-200 -30 -10 25 560', times='2 2 2 2', copy=False)
        close_plots()

        if not dryrun:
            BMMuser.running_macro = False
            BMM_clear_suspenders()
            yield from shb.close_plan()


        ##  EDIT ABOVE THIS LINE
        ### BOILERPLATE BELOW THIS LINE -----------------------------------------------------------
        ### ---------------------------------------------------------------------------------------

    def cleanup_plan():
        yield from end_of_macro()
        yield from xafs_wheel.reset()
        (hours, minutes, seconds) = elapsed_time(start)
        report(f'{BMMuser.instrument} macro finished ({hours} hours, {minutes} minutes)', level='bold', slack=True)
        print(bold_msg('[Hint] to start Athena:\t\t') + '%athena')


    start = time.time()
    
    BMM_suspenders()
    yield from finalize_wrapper(main_plan(ref), cleanup_plan())    
    yield from end_of_macro()
    BMM_log_info('Mn_macro finished!')
